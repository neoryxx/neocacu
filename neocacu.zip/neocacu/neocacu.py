#!/usr/bin/env python3
import os
import platform
import time

# Códigos de cor ANSI
RESET = "\033[0m"
BOLD = "\033[1m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
GREEN = "\033[92m"
RED = "\033[91m"
MAGENTA = "\033[95m"

def exibir_banner():
    banner = f"""{BOLD}{CYAN}
███╗   ██╗███████╗ ██████╗  ██████╗ █████╗  ██████╗██╗   ██╗
████╗  ██║██╔════╝██╔═══██╗██╔════╝██╔══██╗██╔════╝██║   ██║
██╔██╗ ██║█████╗  ██║   ██║██║     ███████║██║     ██║   ██║
██║╚██╗██║██╔══╝  ██║   ██║██║     ██╔══██║██║     ██║   ██║
██║ ╚████║███████╗╚██████╔╝╚██████╗██║  ██║╚██████╗╚██████╔╝
╚═╝  ╚═══╝╚══════╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ 
              N E O C A C U   P L U S

         Feito com ❤️   |   by neoryxx
{RESET}"""
    print(banner)

def exibir_info():
    print(f"{YELLOW}Sistema: {platform.system()} {platform.release()} | Python: {platform.python_version()}{RESET}")
    print(f"{GREEN}Pronto para calcular com estilo! 🧮{RESET}\n")
    time.sleep(1)

def somar(x, y): return x + y
def subtrair(x, y): return x - y
def multiplicar(x, y): return x * y
def dividir(x, y): return x / y if y != 0 else f"{RED}Erro: divisão por zero!{RESET}"

def calculadora():
    while True:
        print(f"{MAGENTA}╔════════════════════════════╗")
        print("║          M E N U           ║")
        print("╟────────────────────────────╢")
        print("║ 1 - Somar                  ║")
        print("║ 2 - Subtrair               ║")
        print("║ 3 - Multiplicar            ║")
        print("║ 4 - Dividir                ║")
        print("║ 5 - Sair                   ║")
        print("╚════════════════════════════╝" + RESET)

        opcao = input("Escolha uma opção: ")

        if opcao == '5':
            print(f"\n{CYAN}Até logo! Obrigado por usar o NEOCACU PLUS ✨{RESET}")
            break
        if opcao not in ['1','2','3','4']:
            print(f"{RED}Opção inválida! Tente novamente.{RESET}\n")
            continue

        try:
            num1 = float(input("Número 1: "))
            num2 = float(input("Número 2: "))
        except ValueError:
            print(f"{RED}Digite apenas números válidos!{RESET}\n")
            continue

        operacoes = {'1': somar, '2': subtrair, '3': multiplicar, '4': dividir}
        resultado = operacoes[opcao](num1, num2)

        print(f"{GREEN}Resultado: {resultado}{RESET}\n")

if __name__ == "__main__":
    os.system('clear')  # Use 'cls' no Windows
    exibir_banner()
    exibir_info()
    calculadora()

