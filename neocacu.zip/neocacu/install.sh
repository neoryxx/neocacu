#!/bin/bash

# Caminho do destino
DESTINO="/usr/local/bin/neocacu"

echo "Instalando Neocacu..."

# Copia o arquivo neocacu.py para o destino
sudo cp neocacu.py $DESTINO

# Dá permissão de execução
sudo chmod +x $DESTINO

echo "Neocacu instalado com sucesso!"
echo "Agora você pode usar o comando: neocacu"

exit 0
